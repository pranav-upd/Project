This is a website that has information abut either gaining weight or losing weight. It has 4 pages which are contact, gain, home and lose.
The contact  page is where you can contact me directly if you have any issues or you want to provide any information. The gain page is the page
which contains information about gaining mass. The home page contains basic information about weight loss and a Basal metabolic rate calculator.
The lose page contains information about losing weight. This concludes my project.